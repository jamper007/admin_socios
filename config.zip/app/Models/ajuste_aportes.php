<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ajuste_aportes extends Model
{
    //
}
