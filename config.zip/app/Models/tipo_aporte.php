<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tipo_aporte extends Model
{
    //
}
