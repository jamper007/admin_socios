@extends('layouts.website')

@section('content')
<div class="container">
    <h1>Bienvenido a la página de inicio</h1>
</div>
@endsection