@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Página de Captura</h1>
    <p>Esta es la página de captura de fotos.</p>
</div>
@endsection