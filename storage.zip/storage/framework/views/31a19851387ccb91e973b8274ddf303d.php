

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><h2>Nuevo Socio</h2></div>
        
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Por favor corrige los siguientes errores:</strong>
                <br><br>
                <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('socios.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="num_socio" class="form-label">Numero de socio</label>
                        <input class="form-control" type="text" name="num_socio" id="num_socio" value="<?php echo e(old('num_socio')); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label">Nombres</label>
                        <input class="form-control" type="text" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="apellido" class="form-label">Apellidos</label>
                        <input class="form-control" type="text" name="apellido" id="apellido" value="<?php echo e(old('apellido')); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="dni" class="form-label">DNI</label>
                        <input class="form-control" type="number" name="dni" id="dni" value="<?php echo e(old('dni')); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="telefono" class="form-label">Telefono</label>
                        <input class="form-control" type="text" name="telefono" id="telefono" value="<?php echo e(old('telefono')); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="direccion" class="form-label">Direccion</label>
                        <input class="form-control" type="text" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input class="form-control" type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="fecha_nacimiento" class="form-label">Fecha de nacimiento</label>
                        <input class="form-control" type="date" name="fecha_nacimiento" id="fecha_nacimiento"
                            value="<?php echo e(old('fecha_nacimiento')); ?>"  
                            min="<?php echo e(date('Y-m-d', strtotime('-120 years'))); ?>" 
                            max="<?php echo e(date('Y-m-d')); ?>" 
                            required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="fecha_ingreso" class="form-label">Fecha de inscripcion</label>
                        <input class="form-control" type="date" name="fecha_ingreso" id="fecha_ingreso" 
                            value="<?php echo e(old('fecha_ingreso')); ?>" 
                            min="<?php echo e(date('Y-m-d', strtotime('-46 years'))); ?>" 
                            max="<?php echo e(date('Y-m-d')); ?>"
                            required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="imagen" class="form-label">Foto</label>
                        <input class="form-control" type="file" name="imagen" id="imagen" value="<?php echo e(old('imagen')); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-control" name="estado" id="estado" required>
                            <option value="1">Activo</option>
                            <option value="0">Inactivo</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 text-center">
                        <button class="btn btn-primary" type="submit">
                            <i class="fa fa-save"></i> Guardar
                        </button>
                        
                        <a class="btn btn-success" class="nav-link"
                         href="<?php echo e(url('/fotos/captura')); ?>"><?php echo e(__('Tomar Fotos')); ?>

                        </a> 

                        <a class="btn btn-info" href="<?php echo e(url('socios/')); ?>"> 
                            <i class="fa fa-arrow-left"></i> Regresar
                        </a>                     
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richi\Desktop\asicle\asicle_app\resources\views/socio/create.blade.php ENDPATH**/ ?>