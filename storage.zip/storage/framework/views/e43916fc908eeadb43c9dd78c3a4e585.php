

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Bienvenido a la página de inicio</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richi\Desktop\asicle\asicle_app\resources\views/inicio.blade.php ENDPATH**/ ?>