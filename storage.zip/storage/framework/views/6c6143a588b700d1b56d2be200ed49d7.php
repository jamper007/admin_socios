

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Página de Captura</h1>
    <p>Esta es la página de captura de fotos.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richi\Desktop\asicle\asicle_app\resources\views/socio/captura.blade.php ENDPATH**/ ?>