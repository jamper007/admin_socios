


<?php $__env->startSection('content'); ?>
<div
    class="container"
>
<div class="card">
    <div class="card-header"><h2>Fotografia del Socio </h2></div>
    <div class="card-body">
    
    </div>
    
<br>
<?php echo e(ucfirst( old('nombre', $socio->nombre))); ?>

 <?php echo e(ucfirst( old('apellido', $socio->apellido) )); ?>

<br>
<br>
 
</div>
<?php if($socio->imagen): ?>
            <img src="<?php echo e(asset('storage/imagenes/' . $socio->imagen)); ?>"
             alt="Foto de <?php echo e($socio->nombre); ?>" width="400">
        <?php else: ?>
            No hay foto disponible
    <?php endif; ?>
    <a href="<?php echo e(url('socios/')); ?>" class="btn btn-success"> Regresar </a>
    <?php $__env->stopSection(); ?>
</div>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richi\Desktop\asicle\asicle_app\resources\views/socio/show.blade.php ENDPATH**/ ?>