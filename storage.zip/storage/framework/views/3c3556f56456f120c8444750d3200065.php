

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="card">
        <div class="card-header"><h3>Listado de Socios</h3></div>
        <div class="card-body">
            <a href="<?php echo e(url('socios/create')); ?>" class="btn btn-success">
            <i class="fa fa-book"></i>
            Nuevo Socio <a/>
            <br>
            <br>
            <table border="1" class="table" >
    
            <tr>
            <th>Numero de socio</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>DNI</th>
            <th>Telefono</th>
            <th>Direccion</th>
            <th>Email</th>
            <th>Fecha de nacimiento</th>
            <th>Fecha de inscripcion</th>
            <th>Estado</th>
            <th>Foto</th>
            <th>Acciones</th>
            </tr>
 
    
            <?php $__currentLoopData = $MostrarSocios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
    
            <td>
            <?php echo e($socio->num_socio); ?> 
            </td>
            <td>
            <?php echo e(ucwords( $socio->nombre)); ?>

            </td>
            <td>
            <?php echo e(ucwords( $socio->apellido )); ?>

            </td>
            <td>
            <?php echo e($socio->dni); ?>

            </td>
            <td>
            <?php echo e($socio->telefono); ?>

            </td>
            <td>
         <?php echo e(ucwords( $socio->direccion)); ?>

            </td>
            <td>
            <?php echo e($socio->email); ?>

            </td>
            <td>
         <?php echo e($socio->fecha_nacimiento); ?>

            </td>
            <td>
            <?php echo e($socio->fecha_ingreso); ?>

            </td>
            <td>
            <?php echo e(ucfirst($socio->estado)); ?>

            </td>
            <td>
        
            <?php if($socio->imagen): ?>
            <img src="<?php echo e(asset('storage/imagenes/' . $socio->imagen)); ?>" alt="Foto de <?php echo e($socio->nombre); ?>" width="50">
            <?php else: ?>
            No hay foto disponible
            <?php endif; ?>

            </td>
            <td>
            <div class="btn-group" role="group">
                <a href="<?php echo e(route('socios.show', $socio)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i>Ver</a>
                <a href="<?php echo e(route('socios.edit', $socio)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Editar</a>
                <form action="<?php echo e(route('socios.destroy', $socio->id)); ?>" method="POST" class="d-inline-">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm"></i><i class="fa fa-trash"></i>Eliminar</button>
                </form>
            </div>
            </td>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo $MostrarSocios->Links(); ?>

        </div>
   
    </div>
    
</div>



   


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richi\Desktop\asicle\asicle_app\resources\views/socio/index.blade.php ENDPATH**/ ?>